package com.elementpowers.client;

import com.elementpowers.ActionPayload;
import com.elementpowers.ElementPowers;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;

public class ElementPowersClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		KeyMapping.Category category = KeyMapping.Category.register(
				Identifier.fromNamespaceAndPath(ElementPowers.MOD_ID, "main"));

		KeyMapping useKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
				"key.elementpowers.use", InputConstants.Type.KEYSYM, InputConstants.KEY_R, category));
		KeyMapping cycleKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
				"key.elementpowers.cycle", InputConstants.Type.KEYSYM, InputConstants.KEY_G, category));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (useKey.consumeClick()) {
				if (client.player != null) ClientPlayNetworking.send(new ActionPayload(0));
			}
			while (cycleKey.consumeClick()) {
				if (client.player != null) ClientPlayNetworking.send(new ActionPayload(1));
			}
		});
	}
}
