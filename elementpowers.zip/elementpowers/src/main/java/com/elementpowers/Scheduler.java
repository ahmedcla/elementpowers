package com.elementpowers;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.IntConsumer;

/** Tiny tick scheduler (runs on the server thread). */
public final class Scheduler {
	private static final class Task {
		int delay;
		int times;
		int idx;
		IntConsumer fn;
	}

	private static final List<Task> tasks = new ArrayList<>();
	private static final List<Task> pending = new ArrayList<>();

	private Scheduler() {}

	public static void later(int delay, Runnable r) {
		Task t = new Task();
		t.delay = delay;
		t.times = 1;
		t.fn = i -> r.run();
		pending.add(t);
	}

	/** Runs fn(0..times-1) once per tick. */
	public static void repeat(int times, IntConsumer fn) {
		Task t = new Task();
		t.delay = 0;
		t.times = times;
		t.fn = fn;
		pending.add(t);
	}

	public static void tick() {
		tasks.addAll(pending);
		pending.clear();
		Iterator<Task> it = tasks.iterator();
		while (it.hasNext()) {
			Task t = it.next();
			if (t.delay > 0) {
				t.delay--;
				continue;
			}
			try {
				t.fn.accept(t.idx++);
			} catch (Exception e) {
				e.printStackTrace();
				it.remove();
				continue;
			}
			if (--t.times <= 0) it.remove();
		}
	}

	public static void clear() {
		tasks.clear();
		pending.clear();
	}
}
