package com.elementpowers;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Client -> server. action 0 = use selected ability, 1 = cycle selected ability. */
public record ActionPayload(int action) implements CustomPacketPayload {
	public static final CustomPacketPayload.Type<ActionPayload> ID =
			new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath(ElementPowers.MOD_ID, "action"));

	public static final StreamCodec<RegistryFriendlyByteBuf, ActionPayload> CODEC =
			StreamCodec.composite(ByteBufCodecs.INT, ActionPayload::action, ActionPayload::new);

	@Override
	public Type<? extends CustomPacketPayload> type() {
		return ID;
	}
}
